<?php
namespace Com\Aleafs;
class AutoLoadOrderTestClass
{
	public function path()
	{
		return __FILE__;
	}
}

