#!/bin/sh
LANG=en_US.UTF8

phing $*
exit $?
